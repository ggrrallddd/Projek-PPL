<?php
$hostname = 'localhost';
$userdb = 'root';
$pasdb = '';
$namedb = 'galery';

$koneksi = mysqli_connect($hostname, $userdb, $pasdb, $namedb);

?>